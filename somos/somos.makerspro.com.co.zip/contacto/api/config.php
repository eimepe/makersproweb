<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'M9yQ3rytoTBLDJM5UUVMDw');
    define('CONSUMER_SECRET', 'fdHZasefjkXijW2Cw1kz7HrW7bKSFjAjUQk1IJgboRI');

    // User Access Token
    define('ACCESS_TOKEN', '2423529476-QCsijYroJXDMP6zsF26CPrykHgEMcPbUbMvsrw9');
    define('ACCESS_SECRET', 'iVlKfAs2xVlChWATEZnzq8QnkuubwSMOk7NebJh5OyVMq');