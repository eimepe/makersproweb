<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=videos',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
